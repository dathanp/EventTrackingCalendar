package com.example.dathanpompaeventtrackingapp;

public class Event {
    private long eventId;
    private String eventName;
    private String eventDescription;
    private String eventDate;
    private String eventTime;


    public Event(long eventId, String eventName, String eventDescription, String eventDate, String eventTime) {
        this.eventId = eventId;
        this.eventName = eventName;
        this.eventDescription = eventDescription;
        this.eventDate = eventDate;
        this.eventTime = eventTime;

    }

    public long getEventId(){
        return eventId;
    }

    public String getEventName() {
        return eventName;
    }

    public String getEventDescription() {
        return eventDescription;
    }

    public String getEventDate() {
        return eventDate;
    }

    public String getEventTime() {
        return eventTime;
    }

}