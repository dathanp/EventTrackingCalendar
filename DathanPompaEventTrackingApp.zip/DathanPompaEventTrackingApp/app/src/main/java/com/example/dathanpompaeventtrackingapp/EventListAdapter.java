package com.example.dathanpompaeventtrackingapp;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EventListAdapter extends RecyclerView.Adapter<EventListAdapter.EventViewHolder> {

    private List<Event> eventList;
    private OnEventDeleteListener onEventDeleteListener;
    private OnEventEditListener onEventEditListener;

    public EventListAdapter(List<Event> eventList, OnEventDeleteListener onEventDeleteListener, OnEventEditListener onEventEditListener) {
        this.eventList = eventList;
        this.onEventDeleteListener = onEventDeleteListener;
        this.onEventEditListener = onEventEditListener;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_event, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Event event = eventList.get(position);
        holder.eventNameTextView.setText(event.getEventName());
        holder.eventDescriptionTextView.setText(event.getEventDescription());
        holder.eventDateTextView.setText(event.getEventDate());
        holder.eventTimeTextView.setText(event.getEventTime());

        Log.d("EventListAdapter", "Event ID being passed: " + event.getEventId());

        holder.editButton.setOnClickListener(v -> {
            if (onEventEditListener != null) {
                onEventEditListener.onEdit(event); // Pass the full event object for editing
            }
        });

        // Handle delete button click
        holder.deleteButton.setOnClickListener(v -> {
            if (onEventDeleteListener != null) {
                onEventDeleteListener.onDelete(event.getEventId()); // Pass the event ID to delete
            }
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView eventNameTextView, eventDescriptionTextView, eventDateTextView, eventTimeTextView;
        ImageButton deleteButton, editButton;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            eventNameTextView = itemView.findViewById(R.id.eventNameTextView);
            eventDescriptionTextView = itemView.findViewById(R.id.eventDescriptionTextView);
            eventDateTextView = itemView.findViewById(R.id.eventDateTextView);
            eventTimeTextView = itemView.findViewById(R.id.eventTimeTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            editButton = itemView.findViewById(R.id.editButton);
        }
    }
    // Interface to handle event deletion
    public interface OnEventDeleteListener {
        void onDelete(long eventId);
    }

    // Interface to handle event editing
    public interface OnEventEditListener {
        void onEdit(Event event); // Pass the entire event object
    }
}