package com.example.dathanpompaeventtrackingapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SmsNotificationsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    private TextView smsPermissionStatus;
    private Button requestSmsPermissionButton;
    private ImageButton backToEventsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_notifications);

        smsPermissionStatus = findViewById(R.id.smsPermissionStatus);
        requestSmsPermissionButton = findViewById(R.id.requestSmsPermissionButton);
        backToEventsButton = findViewById(R.id.backToEventsButton);

        // Back button to go back to the event activity
        backToEventsButton.setOnClickListener(v -> finish());

        // Check SMS permission and update status on create
        checkAndRequestSmsPermission();

        // Request SMS permission when the button is clicked
        requestSmsPermissionButton.setOnClickListener(v -> checkAndRequestSmsPermission());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Method to check and request SMS permission
    private void checkAndRequestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Update the status TextView
            smsPermissionStatus.setText("SMS Permission Status: Not Granted");
            smsPermissionStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));

            // If permission is not granted, request it
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            // Permission already granted, update the status and send SMS
            smsPermissionStatus.setText("SMS Permission Status: Granted");
            smsPermissionStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));

            // Call method to send SMS (this could be triggered by another event, such as an upcoming event)
            sendSmsNotification("1234567890", "This is your event reminder!");
        }
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, update the status and send SMS
                smsPermissionStatus.setText("SMS Permission Status: Granted");
                smsPermissionStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));

                sendSmsNotification("1234567890", "This is your event reminder!");
            } else {
                // Permission denied, update the status
                smsPermissionStatus.setText("SMS Permission Status: Denied");
                smsPermissionStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));

                Toast.makeText(this, "Permission denied. SMS notifications will not be sent.", Toast.LENGTH_LONG).show();
            }
        }
    }

    // Method to send SMS notification
    private void sendSmsNotification(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(getApplicationContext(), "SMS sent successfully!", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "SMS failed to send.", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
}