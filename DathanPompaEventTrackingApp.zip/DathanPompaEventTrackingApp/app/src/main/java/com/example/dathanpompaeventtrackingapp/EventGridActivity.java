package com.example.dathanpompaeventtrackingapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.dathanpompaeventtrackingapp.EventListAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class EventGridActivity extends AppCompatActivity implements EventListAdapter.OnEventDeleteListener, EventListAdapter.OnEventEditListener{

    private RecyclerView calendarRecyclerView;
    private RecyclerView eventListView;
    private CalendarAdapter calendarAdapter;
    private EventListAdapter eventListAdapter;
    private List<String> daysOfMonth;
    private List<String> eventDays;
    private List<Event> eventList;
    private CalendarDatabase calendarDatabase;
    private long loggedInUserId;
    private LinearLayout monthNavigation;
    private FloatingActionButton addEventButton;
    private ImageButton invitationsButton;
    private int currentMonth;
    private int currentYear;

    private TextView monthName;
    private ImageButton deleteButton;
    private Button allEventsButton;
    private Button smsNotification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_event_grid);

        calendarDatabase = new CalendarDatabase(this);
        calendarRecyclerView = findViewById(R.id.calendarListView);
        eventListView = findViewById(R.id.eventListView);
        monthName = findViewById(R.id.monthName);
        allEventsButton = findViewById(R.id.allEventsButton);
        monthNavigation = findViewById(R.id.monthNavigation);
        ImageButton leftArrow = findViewById(R.id.leftArrow);
        ImageButton rightArrow = findViewById(R.id.rightArrow);
        addEventButton = findViewById(R.id.addEventButton);
        ImageButton backButton = findViewById(R.id.backButton);
        smsNotification = findViewById(R.id.smsNotification);
        deleteButton = findViewById(R.id.deleteButton);

        loggedInUserId = getIntent().getLongExtra("USER_ID", -1);

        Calendar calendar = Calendar.getInstance();
        currentMonth = calendar.get(Calendar.MONTH);
        currentYear = calendar.get(Calendar.YEAR);
        //updates month and days
        updateMonthDisplay();
        setupCalendar();

        // Set OnClickListener to open SmsNotificationsActivity
        smsNotification.setOnClickListener(v -> {
            Intent intent = new Intent(EventGridActivity.this, SmsNotificationsActivity.class);
            startActivity(intent);  // Start the SmsNotificationsActivity
        });

        backButton.setOnClickListener(v -> {
            logOutAndNavigateToLogin();
        });

        // Handle previous month navigation
        leftArrow.setOnClickListener(v -> {
            currentMonth--;
            if (currentMonth < 0) {
                currentMonth = 11;  // December
                currentYear--;      // Go to the previous year
            }
            updateMonthDisplay();
            setupCalendar();
        });

        // Handle next month navigation
        rightArrow.setOnClickListener(v -> {
            currentMonth++;
            if (currentMonth > 11) {
                currentMonth = 0;   // January
                currentYear++;      // Go to the next year
            }
            updateMonthDisplay();
            setupCalendar();
        });

        FloatingActionButton addEventButton = findViewById(R.id.addEventButton);
        addEventButton.setOnClickListener(v -> {
            // Create an intent to open AddEventActivity
            Intent intent = new Intent(EventGridActivity.this, AddEventActivity.class);
            // Pass the logged-in user ID if necessary
            intent.putExtra("USER_ID", loggedInUserId);
            startActivity(intent);
        });

        allEventsButton.setOnClickListener(v -> toggleCalendarAndEventList());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

   // @Override
    public void onEdit(Event event) {
        Intent intent = new Intent(EventGridActivity.this, AddEventActivity.class);
        intent.putExtra("EVENT_ID", event.getEventId());
        intent.putExtra("EVENT_NAME", event.getEventName());
        intent.putExtra("EVENT_DESCRIPTION", event.getEventDescription());
        intent.putExtra("EVENT_DATE", event.getEventDate());
        intent.putExtra("EVENT_TIME", event.getEventTime());
        startActivity(intent); // Start AddEventActivity for editing
    }

    @Override
    public void onDelete(long eventId) {
        Log.d("EventGridActivity", "Deleting event with ID: " + eventId);
        // Call the method in your database to delete the event
        calendarDatabase.deleteEvent(eventId);

        // Show a toast to indicate the event was deleted
        Toast.makeText(this, "Event deleted", Toast.LENGTH_SHORT).show();

        loadEventList();

        // Remove the event from the list and notify the adapter
        for (int i = 0; i < eventList.size(); i++) {
            if (eventList.get(i).getEventId() == eventId) {
                eventList.remove(i); // Remove the event from the list
                eventListAdapter.notifyItemRemoved(i); // Notify adapter of the removal
                Toast.makeText(this, "Event deleted", Toast.LENGTH_SHORT).show();
                verifyDeletion(loggedInUserId);
                break;
            }
        }
    }

    private void loadEventList() {
        eventList = new ArrayList<>();
        Cursor cursor = calendarDatabase.getAllEvents(loggedInUserId);
        if (cursor.moveToFirst()) {
            do {
                String eventName = cursor.getString(cursor.getColumnIndexOrThrow("event_name"));
                String eventDescription = cursor.getString(cursor.getColumnIndexOrThrow("event_desc"));
                String eventDate = cursor.getString(cursor.getColumnIndexOrThrow("event_date"));
                String eventTime = cursor.getString(cursor.getColumnIndexOrThrow("event_time"));
                long eventId = cursor.getLong(cursor.getColumnIndexOrThrow("event_id"));

                // Add event to the list
                eventList.add(new Event(eventId, eventName, eventDescription, eventDate, eventTime));
            } while (cursor.moveToNext());
        }
        cursor.close();

        Log.d("EventGridActivity", "Event List Size: " + eventList.size());
        for (Event event : eventList) {
            Log.d("EventGridActivity", "Event Name: " + event.getEventName());
        }

        if (!eventList.isEmpty()) {
            Event firstEvent = eventList.get(0);
            updateEventDetails(firstEvent);
            setupDeleteEvent(firstEvent);
        }
        // Update the RecyclerView adapter
        eventListAdapter = new EventListAdapter(eventList, this, this);
        eventListView.setLayoutManager(new LinearLayoutManager(this));
        eventListView.setAdapter(eventListAdapter);
    }

    // Update the event details section dynamically
    private void updateEventDetails(Event event) {
        TextView eventNameTextView = findViewById(R.id.eventName);
        TextView eventDateTextView = findViewById(R.id.eventDate);
        TextView eventTimeTextView = findViewById(R.id.eventTime);

        // Update TextViews with event details
        eventNameTextView.setText(event.getEventName());
        eventDateTextView.setText(event.getEventDate());
        eventTimeTextView.setText(event.getEventTime());

        // Make event details section visible
        LinearLayout eventDetailsLayout = findViewById(R.id.eventDetails);
        eventDetailsLayout.setVisibility(View.VISIBLE);

        if (!eventList.isEmpty()) {
            Event firstEvent = eventList.get(0);
            updateEventDetails(firstEvent);
            setupDeleteEvent(firstEvent);
        }
    }

    // Set up delete event logic
    private void setupDeleteEvent(Event event) {
        TextView eventNameDeleteTextView = findViewById(R.id.eventName_delete);
        TextView eventDateDeleteTextView = findViewById(R.id.eventDate_delete);
        TextView eventTimeDeleteTextView = findViewById(R.id.eventTime_delete);
        ImageButton deleteButton = findViewById(R.id.deleteButton);

        // Update TextViews with event details for delete section
        eventNameDeleteTextView.setText(event.getEventName());
        eventDateDeleteTextView.setText(event.getEventDate());
        eventTimeDeleteTextView.setText(event.getEventTime());

        // Make delete section visible (if initially invisible)
        LinearLayout deleteEventLayout = findViewById(R.id.deleteEvent);
        deleteEventLayout.setVisibility(View.VISIBLE);

        // Set up delete button action
        deleteButton.setOnClickListener(v -> {
            // Handle event deletion
            onDelete(event.getEventId());
        });
    }

    private void verifyDeletion(long userId) {
        Cursor cursor = calendarDatabase.getAllEvents(userId);
        if (!cursor.moveToFirst()) {
            Log.d("EventGridActivity", "No events found after deletion.");
        } else {
            do {
                Log.d("EventGridActivity", "Event still in DB: " + cursor.getString(cursor.getColumnIndexOrThrow("event_name")));
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    private void setupCalendar() {
        daysOfMonth = new ArrayList<>();
        int daysInMonth = getDaysInMonth(currentMonth, currentYear);
        for (int i = 1; i <= daysInMonth; i++) {
            daysOfMonth.add(String.valueOf(i));
        }
        // Fetch event days from the database for the logged-in user
        eventDays = new ArrayList<>();
        Cursor cursor = calendarDatabase.getAllEvents(loggedInUserId);
        if (cursor.moveToFirst()) {
            do {
                String eventDate = cursor.getString(cursor.getColumnIndexOrThrow("event_date"));
                if (isEventInCurrentMonth(eventDate, currentMonth, currentYear)) {
                    String eventDay = getDayFromDate(eventDate);
                    eventDays.add(eventDay); // Add only the day part
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        // calendar view with 7 columns
        calendarRecyclerView.setLayoutManager(new GridLayoutManager(this, 7));
        calendarAdapter = new CalendarAdapter(daysOfMonth, eventDays);
        calendarRecyclerView.setAdapter(calendarAdapter);
    }

    private String getDayFromDate(String date) {
        // Check if the date is null or empty
        if (date == null || date.isEmpty()) {
            return "";  // Return an empty string or some default value
        }

        String[] dateParts;

        // If the date contains slashes MM/dd/yyyy
        if (date.contains("/")) {
            dateParts = date.split("/");
            if (dateParts.length == 3) {
                return dateParts[1]; // Return the day part
            }
        }
        // If the date is in MMddyyyy format (without slashes)
        else if (date.length() == 8) {
            // Extract the day portion
            return date.substring(2, 4);  // Return the day part (dd)
        }

        // If none of the above formats match, return an empty string
        return "";
    }

    // Helper function to check if the event belongs to the currently selected month and year
    private boolean isEventInCurrentMonth(String eventDate, int month, int year) {
        String[] dateParts;

        // handle the eventDate MM/dd/yyyy
        if (eventDate.contains("/")) {
            dateParts = eventDate.split("/");
            if (dateParts.length != 3) {
                return false; // Invalid date format
            }
        } else {
            // Handle eventDate format MMddyyyy without any separators
            if (eventDate.length() != 8) {
                return false; // Invalid date length for MMddyyyy
            }
            // Manually split MMddyyyy into month, day, and year
            dateParts = new String[3];
            dateParts[0] = eventDate.substring(0, 2); // Month
            dateParts[1] = eventDate.substring(2, 4); // Day
            dateParts[2] = eventDate.substring(4, 8); // Year
        }

        int eventMonth = Integer.parseInt(dateParts[0]) - 1;
        int eventYear = Integer.parseInt(dateParts[2]);

        return eventMonth == month && eventYear == year;
    }

    private int getDaysInMonth(int month, int year) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.YEAR, year);
        return calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
    }

    private void updateMonthDisplay() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.MONTH, currentMonth);
        calendar.set(Calendar.YEAR, currentYear);
        String monthDisplay = calendar.getDisplayName(Calendar.MONTH, Calendar.LONG, getResources().getConfiguration().locale);
        monthName.setText(monthDisplay + " " + currentYear);
    }

    private void toggleCalendarAndEventList() {
        if (eventListView.getVisibility() == RecyclerView.INVISIBLE) {
            //calendarRecyclerView.setVisibility(RecyclerView.GONE);
            eventListView.setVisibility(RecyclerView.VISIBLE);
            showEventListView();
        } else {
            // Hide event list and show calendar again
            hideEventListView();
            calendarRecyclerView.setVisibility(RecyclerView.VISIBLE);
        }
    }

    private void showEventListView() {
        eventListView.setAdapter(eventListAdapter);
        eventListView = findViewById(R.id.eventListView);

        // Fetch events from the database and display them in the event list
        eventList = new ArrayList<>();
        Cursor cursor = calendarDatabase.getAllEvents(loggedInUserId);
        if (cursor.moveToFirst()) {
            do {
                // Fetch event details
                String eventName = cursor.getString(cursor.getColumnIndexOrThrow("event_name"));
                String eventDescription = cursor.getString(cursor.getColumnIndexOrThrow("event_desc"));
                String eventDate = cursor.getString(cursor.getColumnIndexOrThrow("event_date"));
                String eventTime = cursor.getString(cursor.getColumnIndexOrThrow("event_time"));
                long eventId = cursor.getLong(cursor.getColumnIndexOrThrow("event_id"));

                // Add event to the list
                eventList.add(new Event(eventId, eventName, eventDescription, eventDate, eventTime));
            } while (cursor.moveToNext());
        }
        cursor.close();

        // Check if the list is empty and add sample data
        if (eventList.isEmpty()) {
            eventList.add(new Event(0,"Event 1", "This is a sample description", "01 Jan 2025", "10:00 AM"));
            eventListView.setVisibility(RecyclerView.VISIBLE);
        }


        // Set up the adapter for the event list
        eventListAdapter = new EventListAdapter(eventList, this, this);
        eventListView.setLayoutManager(new LinearLayoutManager(this));
        eventListView.setAdapter(eventListAdapter);
    }

    private void hideEventListView() {
        // Hide the event list and show the calendar again
        eventListView.setVisibility(RecyclerView.INVISIBLE);
        //calendarRecyclerView.setVisibility(RecyclerView.VISIBLE);
        //monthNavigation.setVisibility(LinearLayout.VISIBLE);
    }

    private void logOutAndNavigateToLogin() {
        // Navigate back to LoginActivity
        Intent intent = new Intent(EventGridActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);  // Clear the back stack
        startActivity(intent);

        // Finish the current activity
        finish();
    }

}