package com.example.dathanpompaeventtrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddEventActivity extends AppCompatActivity {

    private EditText eventNameInput, eventDescriptionInput, eventDateInput, eventTimeInput;
    private Button saveEventButton;
    private CalendarDatabase calendarDatabase;
    private long loggedInUserId;
    private static final String DATE_PATTERN = "\\d{2}/\\d{2}/\\d{4}";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_event);

        eventNameInput = findViewById(R.id.eventNameInput);
        eventDescriptionInput = findViewById(R.id.eventDescriptionInput);
        eventDateInput = findViewById(R.id.eventDateInput);
        eventTimeInput = findViewById(R.id.eventTimeInput);
        saveEventButton = findViewById(R.id.saveEventButton);
        ImageButton eventbackButton = findViewById(R.id.eventBackButton);
        // Initialize the database
        calendarDatabase = new CalendarDatabase(this);
        loggedInUserId = getIntent().getLongExtra("USER_ID", -1);

        // Back to event grid
        eventbackButton.setOnClickListener(v -> {
            finish();
        });

        Intent intent = getIntent();
        if (intent.hasExtra("EVENT_ID")) {
            long eventId = intent.getLongExtra("EVENT_ID", -1);
            if (eventId != -1) {
                // Pre-fill the input fields with the existing event data
                eventNameInput.setText(intent.getStringExtra("EVENT_NAME"));
                eventDescriptionInput.setText(intent.getStringExtra("EVENT_DESCRIPTION"));
                eventDateInput.setText(intent.getStringExtra("EVENT_DATE"));
                eventTimeInput.setText(intent.getStringExtra("EVENT_TIME"));
                // Change the action of saveEventButton to update
                saveEventButton.setOnClickListener(v -> {
                    updateEvent(eventId); // Update the event in the database
                });
            }
        } else {
            // Save the event
            findViewById(R.id.saveEventButton).setOnClickListener(v -> {
                String eventName = eventNameInput.getText().toString();
                String eventDescription = eventDescriptionInput.getText().toString();
                String eventDate = eventDateInput.getText().toString();
                String eventTime = eventTimeInput.getText().toString();


                // Validation to check if name, date, and time are empty
                if (eventName.isEmpty() || eventDate.isEmpty() || eventTime.isEmpty()) {
                    Toast.makeText(AddEventActivity.this, "Please fill in Name, Date, and Time fields", Toast.LENGTH_SHORT).show();
                } else if (!eventDate.matches(DATE_PATTERN)) {
                    // Validate date format
                    Toast.makeText(AddEventActivity.this, "Please enter the date in MM/dd/yyyy format", Toast.LENGTH_SHORT).show();
                } else {
                    // Add the event to the database
                    long eventId = calendarDatabase.addEvent(eventName, eventDescription, eventDate, eventTime, loggedInUserId);

                    if (eventId != -1) {
                        // Show success message and close the activity
                        Toast.makeText(AddEventActivity.this, "Event added successfully", Toast.LENGTH_SHORT).show();
                        finish(); // Go back to EventGridActivity
                    } else {
                        // Show error message if event couldn't be added
                        Toast.makeText(AddEventActivity.this, "Error adding event. Please try again.", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }
    }
    private void updateEvent(long eventId) {
        String eventName = eventNameInput.getText().toString();
        String eventDescription = eventDescriptionInput.getText().toString();
        String eventDate = eventDateInput.getText().toString();
        String eventTime = eventTimeInput.getText().toString();

        if (eventName.isEmpty() || eventDate.isEmpty() || eventTime.isEmpty()) {
            Toast.makeText(this, "Please fill in Name, Date, and Time fields", Toast.LENGTH_SHORT).show();
            return;
        }

        calendarDatabase.updateEvent(eventId, eventName, eventDescription, eventDate, eventTime);

        Toast.makeText(this, "Event updated successfully", Toast.LENGTH_SHORT).show();
        finish(); // Go back to EventGridActivity
    }
}