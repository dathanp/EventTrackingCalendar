package com.example.dathanpompaeventtrackingapp;

import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.DialogInterface;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.appcompat.app.AlertDialog;

public class LoginActivity extends AppCompatActivity {

    private EditText username, password;
    private Button loginButton, createAccountButton;
    private CalendarDatabase calendarDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        calendarDatabase = new CalendarDatabase(this);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // onClickListener for login
        loginButton.setOnClickListener(v -> {
            String user = username.getText().toString().trim();
            String pass = password.getText().toString().trim();

            //Check user input if empty
            if(user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Please do not leave username or password empty", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check credentials with Database
            long loginSuccess = calendarDatabase.loginUser(user, pass);
            if (loginSuccess > 0) {
                // Login successful -> navigate to the Event Grid
                Intent intent = new Intent(LoginActivity.this, EventGridActivity.class);
                intent.putExtra("USER_ID", loginSuccess);
                startActivity(intent);
                // Close the login screen
                finish();
            } else {
                // Login unsuccessful
                showCreateAccountDialog(user, pass);
            }
        });
        // onClickListener for Create Account
        createAccountButton.setOnClickListener(v -> {
            String user = username.getText().toString().trim();
            String pass = password.getText().toString().trim();

            // Validate user input
            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Please fill out both fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Register new user with database
            long userId = calendarDatabase.registerUser(user, pass);
            if (userId > 0) {
                // Account created successfully
                Toast.makeText(LoginActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show();
            } else {
                // Account creation failed
                Toast.makeText(LoginActivity.this, "Failed to create account", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showCreateAccountDialog(String user, String pass){
        // Create an AlertDialog asking if the user wants to create a new account
        new AlertDialog.Builder(this)
                .setTitle("Create Account")
                .setMessage("The username or password is incorrect. Would you like to create a new account?")
                .setPositiveButton("Yes", (dialogInterface, i) -> {
                    // Register the user as a new account
                    long userId = calendarDatabase.registerUser(user, pass);
                    if (userId > 0) {
                        Toast.makeText(LoginActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(LoginActivity.this, "Failed to create account", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("No", (dialogInterface, i) -> {
                    // Dismiss the dialog and let them try again
                    dialogInterface.dismiss();
                })
                .show();
    }


}