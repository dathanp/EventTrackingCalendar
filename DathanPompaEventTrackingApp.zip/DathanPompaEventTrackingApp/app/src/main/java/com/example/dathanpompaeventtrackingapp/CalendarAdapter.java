package com.example.dathanpompaeventtrackingapp;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class CalendarAdapter extends RecyclerView.Adapter<CalendarAdapter.CalendarViewHolder> {

    private List<String> daysOfMonth;
    private List<String> eventDays;

    // Constructor
    public CalendarAdapter(List<String> daysOfMonth, List<String> eventDays) {
        this.daysOfMonth = daysOfMonth;
        this.eventDays = eventDays;
    }

    @NonNull
    @Override
    public CalendarViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_day, parent, false);
        return new CalendarViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CalendarViewHolder holder, int position) {
        String day = daysOfMonth.get(position);
        holder.dayText.setText(day);

        // Check if the day has an event and display the dot
        if (eventDays.contains(day)) {
            holder.eventDot.setVisibility(View.VISIBLE); // Show the event dot
        } else {
            holder.eventDot.setVisibility(View.GONE); // Hide the event dot
        }
    }

    @Override
    public int getItemCount() {
        return daysOfMonth.size();
    }

    // ViewHolder class to hold the day number and event dot
    public static class CalendarViewHolder extends RecyclerView.ViewHolder {
        TextView dayText;
        ImageView eventDot;

        public CalendarViewHolder(@NonNull View itemView) {
            super(itemView);
            dayText = itemView.findViewById(R.id.dayNumberText);
            eventDot = itemView.findViewById(R.id.eventDot);
        }
    }
}